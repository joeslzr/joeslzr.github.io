Name: John Joseph Salazar
ID: 30044409
Section: Lec 01 Tut 03
Browsers Used: Mozilla Firefox, Google Chrome
Website URL: https://joeslzr.github.io/SENG513/Assignment1/index.html